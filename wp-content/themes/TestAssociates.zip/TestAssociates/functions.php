<?php

// fix wp upload size restrictions

ini_set('upload_max_size', '256M');
ini_set('post_max_size', '256M');
ini_set('max_execution_time', '300');
ini_set('mysql.trace_mode', 0);


// register menus

add_theme_support('menus');
register_nav_menus(array(
    'primary' => 'Display this menu in header',
    'footerleft' => 'The left side footer menu',
    'footerright' => 'The right site footer menu',
));

// necessary to use acf block editor stuff

require_once(get_theme_file_path() . '/parts/parts.php');

function block_editor_assets_enqueue()
{
    wp_enqueue_style(
        'my-block-editor-styles',
        get_template_directory_uri() . '/assets/css/style.css',
        [],
        filemtime(get_template_directory() . '/assets/css/style.css')
    );
}
add_action('enqueue_block_editor_assets', 'block_editor_assets_enqueue');


// quality of life style change for guttenburg backend 

add_action('admin_head', 'admin_styles');
function admin_styles()
{
    echo '<style>
            .wp-block {max-width: 1280px;}
            .interface-interface-skeleton__sidebar {max-width: 500px; width: 100%;}
            .interface-complementary-area__fill {max-width: 500px; width: 100% !important;}
            .editor-sidebar {max-width: 500px; width: 100% !important;}
            </style>';
}


// redirect for countried that can't use paypal

add_action('template_redirect', 'redirect_indian_visitors_to_invoice');

function redirect_indian_visitors_to_invoice()
{
    // Don't redirect in admin or if already on the invoice request page
    if (is_admin() || is_page('invoice-request')) {
        return;
    }

    // List of pages to block access to for Indian visitors
    $restricted_pages = [
        'shop',
        'cart',
        'checkout',
        'book-a-table'
    ];

    // Check if the current page matches any restricted page
    foreach ($restricted_pages as $slug) {
        if (is_page($slug) || ($slug === 'shop' && is_shop()) || ($slug === 'cart' && is_cart()) || ($slug === 'checkout' && is_checkout())) {
            // Geolocate user
            $location = WC_Geolocation::geolocate_ip();
            $country = isset($location['country']) ? $location['country'] : '';

            if ($country === 'IN') {
                wp_redirect(site_url('/request-invoice'));
                exit;
            }
        }
    }
}

function redirect_indian_visitors_to_cat_invoice()
{
    // Don't redirect in admin or if already on the invoice request page
    if (is_admin() || is_page('category-sponsorship')) {
        return;
    }

    // List of pages to block access to for Indian visitors
    $restricted_pages = [
        'category-sponsorship'
    ];

    // Check if the current page matches any restricted page
    foreach ($restricted_pages as $slug) {
        if (is_page($slug) || ($slug === 'shop' && is_shop()) || ($slug === 'cart' && is_cart()) || ($slug === 'checkout' && is_checkout())) {
            // Geolocate user
            $location = WC_Geolocation::geolocate_ip();
            $country = isset($location['country']) ? $location['country'] : '';

            if ($country === 'IN') {
                wp_redirect(site_url('/categories-invoice'));
                exit;
            }
        }
    }
}


// Date formatter function for hero

function formatDateWithSuffix($dateString)
{
    $date = new DateTime($dateString);
    $day = (int) $date->format('j');

    // Determine ordinal suffix
    if ($day % 10 == 1 && $day != 11) {
        $suffix = 'st';
    } elseif ($day % 10 == 2 && $day != 12) {
        $suffix = 'nd';
    } elseif ($day % 10 == 3 && $day != 13) {
        $suffix = 'rd';
    } else {
        $suffix = 'th';
    }

    // Format final date string
    return $day . $suffix . ' ' . $date->format('F Y');
}


// WooCom custom template stuff



// function custom_product_title_message() {

// echo '<p>Custom message after the product title!</p>';

// }

// add_action('woocommerce_single_product_summary', 'custom_product_title_message', 20);

// //Add filters to modify content before display. For instance, to change product prices, use a filter like this:

// function custom_price_format($price, $product) {

// return 'Special Price: ' . $price;

// }

// add_filter('woocommerce_get_price_html', 'custom_price_format', 10, 2);



?>