<?php
add_action('acf/init', 'flex_acf_init_block_types');

function flex_acf_init_block_types()
{
    if (function_exists('acf_register_block_type')) {

        acf_register_block_type(array(
            'name' => 'masonry',
            'title' => __('Masonry Block'),
            'description' => __('Masonry section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['masonry'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/masonry.php'
        ));

        acf_register_block_type(array(
            'name' => 'cta',
            'title' => __('CTA Block'),
            'description' => __('CTA section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['cta'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/cta.php'
        ));

        acf_register_block_type(array(
            'name' => 'title',
            'title' => __('Title Block'),
            'description' => __('Title section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['title'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/title.php',
        ));

        acf_register_block_type(array(
            'name' => 'Full Width Content',
            'title' => __('Full Width Content Block'),
            'description' => __('Full Width Content section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['fwc', 'content', 'full width'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/fw.php',
        ));

        acf_register_block_type(array(
            'name' => 'Contact',
            'title' => __('Contact Block'),
            'description' => __('Contact section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['form', 'content', 'contact'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/contact.php',
        ));

        acf_register_block_type(array(
            'name' => 'Full Width Image',
            'title' => __('Full Width Image Block'),
            'description' => __('Full Width Image section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['image', 'content', 'full width'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/fw_img.php',
        ));

        acf_register_block_type(array(
            'name' => 'Full Width Video',
            'title' => __('Full Width Video Block'),
            'description' => __('Full Width Video section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['video', 'content', 'video'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/fw_video.php',
        ));

        acf_register_block_type(array(
            'name' => 'Judging Cards',
            'title' => __('Judging Cards Block'),
            'description' => __('Judging Cards section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['cards', 'content', 'judges'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/jcards.php',
        ));

        acf_register_block_type(array(
            'name' => 'Timeline',
            'title' => __('Timeline Block'),
            'description' => __('Timeline section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['timeline', 'content'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/timeline.php',
        ));

        acf_register_block_type(array(
            'name' => 'Hero',
            'title' => __('Hero Block'),
            'description' => __('Hero section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['hero', 'content'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/hero.php',
        ));

        acf_register_block_type(array(
            'name' => 'Spacer',
            'title' => __('Spacer Block'),
            'description' => __('Spacer section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['spacer', 'content', 'gap'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/spacer.php',
        ));

        acf_register_block_type(array(
            'name' => 'Entry Process',
            'title' => __('Entry Process Block'),
            'description' => __('Entry Process section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['entry', 'content', 'table'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/entry_example.php',
        ));

        acf_register_block_type(array(
            'name' => 'Accordion',
            'title' => __('Accordion Block'),
            'description' => __('Accordion section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['accordion', 'content', 'animated', 'flexible'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/accordion.php',
        ));

        acf_register_block_type(array(
            'name' => 'WooCommerse Loop Process',
            'title' => __('WooCommerse Loop Block'),
            'description' => __('WooCommerse Loop section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['WooCommerce', 'posts', 'products', 'filter', 'modal'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/woocom_loop.php',
        ));

        acf_register_block_type(array(
            'name' => 'Winners',
            'title' => __('Winners Block'),
            'description' => __('Winners section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['alternating', 'content', 'winners', 'awards', 'repeating'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/winners.php',
        ));

        acf_register_block_type(array(
            'name' => 'Finalists',
            'title' => __('Finalist Block'),
            'description' => __('Finalist section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['cards', 'content', 'repeating', 'awards', 'finalists'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/finalists.php',
        ));

        acf_register_block_type(array(
            'name' => 'Sponsor Cards',
            'title' => __('Sponsors Block'),
            'description' => __('Sponsors section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['WooCommersc', 'posts', 'products'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/sponsor_cards.php',
        ));

        acf_register_block_type(array(
            'name' => 'Sponsor Info',
            'title' => __('Sponsor Info Block'),
            'description' => __('Sponsors Info section.'),
            'category' => 'star-filled',
            'icon' => 'welcome-widgets-menus',
            'keywords' => ['WooCommerce', 'posts', 'products'. 'table'],
            'supports' => [
                'align' => true,
                'mode' => true,
                'jsx' => true
            ],
            'render_template' => 'parts/sponsor_info.php',
        ));

    }
}
